def 我():
    return 0

def 非(a):
    return a

def 常(a):
    return a

def 需(a):
    return a

def 要(a, b):
    return a + b

def 放(a, b):
    return a - b

def 屁(a, b):
    return a * b

def 然(a, b):
    return a % b

def 後(a, b):
    return a ** b

def 睡(a, b, m):
    return pow(a, b, m)

def 覺(n):
    print(chr(常(n)), end="", flush=True)
